package com.example.FaceNet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
