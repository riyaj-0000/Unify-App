// ignore_for_file: constant_identifier_names

enum Period {
  Week,
  Month,
  Year,
}
