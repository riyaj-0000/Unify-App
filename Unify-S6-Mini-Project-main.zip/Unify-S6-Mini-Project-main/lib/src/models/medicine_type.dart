// ignore_for_file: constant_identifier_names

enum MedicineType {
  Bottle,
  Pill,
  Syringe,
  // ignore: constant_identifier_names
  Tablet,
  None,
}
