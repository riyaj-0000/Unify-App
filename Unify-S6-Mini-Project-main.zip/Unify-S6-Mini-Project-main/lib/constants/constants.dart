class Constants {
  static String githubURL =
      "https://github.com/MCarlomagno/FaceRecognitionAuth/tree/master";
}
